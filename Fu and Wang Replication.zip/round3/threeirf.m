% median and 16th/84th percentiles of irf of three episodes

%four time slot
t1 = (2006.50-time(1)+0.25)*4;
t3 = (2010.50-time(1)+0.25)*4;
t4 = (2012.50-time(1)+0.25)*4;

a_three = [t1 t3 t4];
response_three = impulse_response(rsmall.A,rsmall.B,rsmall.expH,nstep,a_three);


%irf of 2006.50
i_graph = 1;
figure;
for i = 1:2
    for j = 3:4
        subplot(2,2,i_graph)
        plot(0:20,prctile(squeeze(response_three(1,i,j,:,:))',50),'-b');hold on;
        plot(0:20,prctile(squeeze(response_three(1,i,j,:,:))',error_lower),'--r');
        plot(0:20,prctile(squeeze(response_three(1,i,j,:,:))',error_upper),'--r');grid;
        title(strcat('(',num2str(i_graph),')'));
        i_graph = i_graph + 1;
    end
end
fig = gcf;
fig.PaperUnits = 'inches';
fig.PaperPosition = [0 0 10 8];
saveas(fig,strcat('graphs/three_2006.png'));

i_graph = 1;
figure;
for i = 1:2
    for j = 3:4
        subplot(2,2,i_graph)
        plot(0:20,prctile(squeeze(response_three(2,i,j,:,:))',50),'-b');hold on;
        plot(0:20,prctile(squeeze(response_three(2,i,j,:,:))',error_lower),'--r');
        plot(0:20,prctile(squeeze(response_three(2,i,j,:,:))',error_upper),'--r');grid;
        title(strcat('(',num2str(i_graph),')'));
        i_graph = i_graph + 1;
    end
end
fig = gcf;
fig.PaperUnits = 'inches';
fig.PaperPosition = [0 0 10 8];
saveas(fig,strcat('graphs/three_2010.png'));  

i_graph = 1;
figure;
for i = 1:2
    for j = 3:4
        subplot(2,2,i_graph)
        plot(0:20,prctile(squeeze(response_three(3,i,j,:,:))',50),'-b');hold on;
        plot(0:20,prctile(squeeze(response_three(3,i,j,:,:))',error_lower),'--r');
        plot(0:20,prctile(squeeze(response_three(3,i,j,:,:))',error_upper),'--r');grid;
        title(strcat('(',num2str(i_graph),')'));
        i_graph = i_graph + 1;
    end
end
fig = gcf;
fig.PaperUnits = 'inches';
fig.PaperPosition = [0 0 10 8];
saveas(fig,strcat('graphs/three_2012.png'));  
