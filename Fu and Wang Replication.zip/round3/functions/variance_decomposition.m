%variance decomposition
%yt = theta0*et + theta1*et+1 + ...
%theta_i is the impulse response function of et with horizon i
%Var_n = sum_0^n thetai*thetai' n step ahead variance
n_step_ahead = [1 2 4 8 16];
%response(T,n,n,step,M-N)
%response=impulse_response(rsmall.A,rsmall.B,rsmall.expH,max(n_step_ahead),1:length(time));
response = response_all;

%one step ahead variance
m_n = ndraw_graph;
[T,junk] = size(r.A);
var = zeros(T,r.n,r.n,max(n_step_ahead),m_n);
var_de = zeros(T,r.n,r.n,max(n_step_ahead),m_n);
for i = 1:m_n
    for t = 1:T
        theta_sum = zeros(r.n,r.n);  % redefine theta_sum for every t,i
        for step = 1:max(n_step_ahead)
             theta = squeeze(response(t,:,:,step,i)); %step theta
             theta_sum =  theta_sum + theta.^2;       %sum of theta^2 from 1 to step
             var(t,:,:,step,i) = theta_sum;
             
             %variance decomposition
             temp = sum(squeeze(var(t,:,:,step,i)),2);
             var_de(t,:,:,step,i) = squeeze(var(t,:,:,step,i))./repmat(temp,1,r.n);
        end
    end
end


%variance decomposition of gdp
figure;
i_graph = 1;
for i=1:length(n_step_ahead)
  for j= 1:r.n
    subplot(length(n_step_ahead),r.n,i_graph);
    plot(time,prctile(squeeze(var_de(:,gdp_ind,j,n_step_ahead(i),:))',50),'-b');hold on;grid;
    plot(time,prctile(squeeze(var_de(:,gdp_ind,j,n_step_ahead(i),:))',error_lower),'--r');
    plot(time,prctile(squeeze(var_de(:,gdp_ind,j,n_step_ahead(i),:))',error_upper),'--r');
    set(gca,'xtick',[2000 2009  2018]);axis([2000 2018 -0.1 1.1]);
    title(var_name_short(j));
%     if i~=1 & j ~= 1 & j~=3
%         axis([2000 2018 0 0.6]);
%     end
    i_graph = i_graph + 1;
   end
end
fig = gcf;
fig.PaperUnits = 'inches';
fig.PaperPosition = [0 0 8 8];
saveas(fig,strcat('graphs/var_de_g.png'));
   
  
figure;
i_graph = 1;
for i=1:length(n_step_ahead)
for j= 1:r.n
    subplot(length(n_step_ahead),r.n,i_graph);
    plot(time,prctile(squeeze(var_de(:,inf_ind,j,n_step_ahead(i),:))',50),'-b');hold on;grid;
    plot(time,prctile(squeeze(var_de(:,inf_ind,j,n_step_ahead(i),:))',error_lower),'--r');
    plot(time,prctile(squeeze(var_de(:,inf_ind,j,n_step_ahead(i),:))',error_upper),'--r');
    set(gca,'xtick',[2000 2009 2018]);axis([2000 2018 -0.1 1.1]);
    title(var_name_short(j));
%     if i~=1 & j ~= 2 & j~=3
%         axis([2000 2018 0 0.6]);
%     end
    i_graph = i_graph + 1;
end
end
fig = gcf;
fig.PaperUnits = 'inches';
fig.PaperPosition = [0 0 8 8];
saveas(fig,strcat('graphs/var_de_pi.png'));


    