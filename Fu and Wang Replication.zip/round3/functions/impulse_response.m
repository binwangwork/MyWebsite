function response=impulse_response(AA,BB,HH,nstep,a)
% computes the irf of different dates
% a is a vector which indicates the starting point of the dates
% AA, BB,HH are time varying parameter draws
% n is the number of variables
% lags is the number of lags
% nstep is the number of horizons of irf
% nkeep is the numer of remaining draws


n= size(HH,2);
lags = (size(BB,2)/n-1)/n;
ndraw = size(AA,3);
smat=zeros(n,n);
B_lag=zeros(n,n,lags);
response=zeros(length(a),n,n,nstep,ndraw);
for i=1:ndraw %size(AA,3) is the number of remaining draws
for t=1:length(a)
    smat=tria(AA(a(t),:,i))\diag(HH(a(t),:,i)); %use time t H for irf %delete the transpose from Primiceri
    for i_lag = 1:lags
        for i_eq = 1:n
           B_lag(i_eq,:,i_lag)=BB(a(t),(1+(lags*n+1)*(i_eq-1)+n*(i_lag-1)+1):(1+(lags*n+1)*(i_eq-1)+n*(i_lag-1)+n),i);
        end
    end
    response(t,:,:,:,i)=impulsdtrf(B_lag(:,:,:),smat,nstep);
end
end

          
end
    




