function cd = convergence_cd(x,n0,n1)

[T,n_d,nsim] = size(x);
mean0 = mean(x(:,:,1:n0),3);
mean1 = mean(x(:,:,(nsim-n1+1):nsim),3);
sd0   = std(x(:,:,1:n0),0,3);
sd1   = std(x(:,:,(nsim-n1+1):nsim),0,3);
cd    = (mean0-mean1)./sqrt(sd0.^2+sd1.^2);
end
