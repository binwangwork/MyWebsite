% exclude interest rate


data = csvread('china_macrodata.csv',1,0);
data = data(:,[1 2 3 5]); %exclude the interst rate
var_name = {'GDP Growth Rate' 'Inflation Rate' 'Money Growth Rate'};
var_name_short = {'g','\pi','m'};
mon_ind = 3;

T0 = 20;
r=tvsvar(data,T0,nrep);




rsmall.B=r.B(:,:,[nburn+1:nthin:end]);
rsmall.A=r.A(:,:,[nburn+1:nthin:end]);
rsmall.H=r.H(:,:,[nburn+1:nthin:end]);
rsmall.expH = exp(rsmall.H);     %the original Sigma matrix
ndraw_graph = size(rsmall.B,3);
time = r.yearlab;





%% 1. Parameters -------------------------------------------------------------------------------
%beta plot
figure;
% for i= 1:r.k
%     plot(time,prctile(squeeze(rsmall.B(:,i,:))',50));hold on;
% end
for i = 1:r.n
    subplot(2,2,i);
    for j = r.k/r.n*(i-1)+1:r.k/r.n*i
    plot(time,prctile(squeeze(rsmall.B(:,j,:))',50));hold on;
    end
    title(strcat(var_name(i),' Equation'));
end
fig = gcf;
fig.PaperUnits = 'inches';
fig.PaperPosition = [0 0 8 6];
saveas(fig,'graphs/Robustness2/Bplot.png');


%alpha plot
figure;
i_graph = 1;
i_alpha = 1;
for i = 1:r.n-1
    for j = 1:r.n-1
        subplot(r.n-1,r.n-1,i_graph) 
      if j <= i
        
        plot(time,prctile(squeeze(-rsmall.A(:,i_alpha,:))',50),'-b');hold on;
        plot(time,prctile(squeeze(-rsmall.A(:,i_alpha,:))',error_lower),'--r');
        plot(time,prctile(squeeze(-rsmall.A(:,i_alpha,:))',error_upper),'--r');grid;
        if i ==1
            axis([2000 2018 -0.5 1]);
        elseif i ==2
            axis([2000 2018 -0.5 0.5]);
        else
            axis([2000 2018 -1 1.2]);
        end
        title(strcat({'('},num2str(i_alpha),{'): '},var_name_short(i+1), {' to '}, var_name_short(j)));
        i_alpha = i_alpha + 1;
      end
      i_graph = i_graph +1;
    end   
end
fig = gcf;
fig.PaperUnits = 'inches';
fig.PaperPosition = [0 0 8 8];
saveas(fig,'graphs/Robustness2/Aplot.png');



%Sigma plot
figure;
for i = 1:r.n
    subplot(r.n,1,i)
    plot(time,prctile(squeeze(rsmall.expH(:,i,:))',50),'-b');hold on;
    plot(time,prctile(squeeze(rsmall.expH(:,i,:))',error_lower),'--r');
    plot(time,prctile(squeeze(rsmall.expH(:,i,:))',error_upper),'--r');grid;
    title(var_name_short(i));
%     if i ==3
%         axis([2000 2018 0 1]);
    if i==1
        axis([2000 2018 0 2]);
    else
        axis([2000 2018 0 1.5]);
    end
end
fig = gcf;
fig.PaperUnits = 'inches';
fig.PaperPosition = [0 0 8 8];
saveas(fig,'graphs/Robustness2/Sigplot.png');


%% 2. Impulse Response Functions --------------------------------------------------------------------------

% I will illustrate the irf to four periods: 2001:50-2007.50; 2008-2008.75;
% 2009-2010.75; 2012-2013
% six panels; panel 1-4 illustrates the irf of one time in these 4
% episodes; panel 5 shows the median of the first episode; panel 6 shows
% the median of the four episodes
a_all = (time-time(1)+0.25)*4;
a_before_fc = ([time(1):0.25:2007.50]-time(1)+0.25)*4;
a_fc_before_sti = ([2008:0.25:2008.75]-time(1)+0.25)*4;
a_fc_in_sti = ([2010:0.25:2010.75]-time(1)+0.25)*4;
a_fc_after_sti = ([2012:0.25:2014]-time(1)+0.25)*4;

response_all = impulse_response(rsmall.A,rsmall.B,rsmall.expH,nstep,a_all);
response_before_fc = impulse_response(rsmall.A,rsmall.B,rsmall.expH,nstep,a_before_fc);
response_fc_before_sti = impulse_response(rsmall.A,rsmall.B,rsmall.expH,nstep,a_fc_before_sti);
response_fc_in_sti = impulse_response(rsmall.A,rsmall.B,rsmall.expH,nstep,a_fc_in_sti);
response_fc_after_sti = impulse_response(rsmall.A,rsmall.B,rsmall.expH,nstep,a_fc_after_sti);

%four time slot
t1 = (2006.50-2001.25+0.25)*4;
t3 = (2010.50-2010+0.25)*4;
t4 = (2012.50-2012+0.25)*4;

% % irf of g to i-------------------------------------------------------------------------------------------------------------
% figure;
% subplot(3,2,1)
% for t =1:length(a_all)
%     plot(0:20,prctile(squeeze(response_all(t,gdp_ind,int_ind,:,:))',50));hold on;grid;
% end
% %axis([0 20 -0.8 0.8]);
% title('(1)');
% subplot(3,2,2)
% for t =1:length(a_before_fc)
%     if t==1
%         h1 = plot(0:20,prctile(squeeze(response_before_fc(t,gdp_ind,int_ind,:,:))',50),'black');hold on;grid;
%     end
%     plot(0:20,prctile(squeeze(response_before_fc(t,gdp_ind,int_ind,:,:))',50),'black')
% end
% 
% for t =1:length(a_fc_before_sti)
%     if t==1
%         h2 = plot(0:20,prctile(squeeze(response_fc_before_sti(t,gdp_ind,int_ind,:,:))',50),'blue');hold on;grid;
%     end
%     plot(0:20,prctile(squeeze(response_fc_before_sti(t,gdp_ind,int_ind,:,:))',50),'blue')
% end
% 
% for t =1:length(a_fc_in_sti)
%     if t==1
%         h3 = plot(0:20,prctile(squeeze(response_fc_in_sti(t,gdp_ind,int_ind,:,:))',50),'yellow');hold on;grid;
%     end
%     plot(0:20,prctile(squeeze(response_fc_in_sti(t,gdp_ind,int_ind,:,:))',50),'yellow')
% end
% 
% for t =1:length(a_fc_after_sti)
%     if t==1
%         h4 = plot(0:20,prctile(squeeze(response_fc_after_sti(t,gdp_ind,int_ind,:,:))',50),'red');hold on;grid;
%     end
%     plot(0:20,prctile(squeeze(response_fc_after_sti(t,gdp_ind,int_ind,:,:))',50),'red')
% end
% grid; set(gca,'xtick',[0 5 10 15 20]); hold on;%axis([0 20 -0.8 0.8]);
% title('(2)');
% lgd = legend([h1 h2 h3 h4],{'2001-2007','2008','2009-2010','2012-2014'});
% lgd.FontSize = 7;
% subplot(3,2,3)
% plot(0:20,prctile(squeeze(response_before_fc(t1,gdp_ind,int_ind,:,:))',50),'-b*');hold on;grid;
% plot(0:20,prctile(squeeze(response_fc_in_sti(t3,gdp_ind,int_ind,:,:))',50),'-bd');
% plot(0:20,prctile(squeeze(response_fc_after_sti(t4,gdp_ind,int_ind,:,:))',50),'-b+');
% legend('2006:Q3','2010:Q3','2012:Q3');
% title('(3)');
% subplot(3,2,4)
% plot(0:20,prctile(squeeze(response_fc_in_sti(t3,gdp_ind,int_ind,:,:)-response_before_fc(t1,gdp_ind,int_ind,:,:))',50),'-b');hold on;grid;
% plot(0:20,prctile(squeeze(response_fc_in_sti(t3,gdp_ind,int_ind,:,:)-response_before_fc(t1,gdp_ind,int_ind,:,:))',error_lower),'--r');
% plot(0:20,prctile(squeeze(response_fc_in_sti(t3,gdp_ind,int_ind,:,:)-response_before_fc(t1,gdp_ind,int_ind,:,:))',error_upper),'--r');
% title('(4)');
% subplot(3,2,5)
% plot(0:20,prctile(squeeze(response_fc_after_sti(t4,gdp_ind,int_ind,:,:)-response_before_fc(t1,gdp_ind,int_ind,:,:))',50),'-b');hold on;grid;
% plot(0:20,prctile(squeeze(response_fc_after_sti(t4,gdp_ind,int_ind,:,:)-response_before_fc(t1,gdp_ind,int_ind,:,:))',error_lower),'--r');
% plot(0:20,prctile(squeeze(response_fc_after_sti(t4,gdp_ind,int_ind,:,:)-response_before_fc(t1,gdp_ind,int_ind,:,:))',error_upper),'--r');
% title('(5)');
% subplot(3,2,6)
% plot(0:20,prctile(squeeze(response_fc_after_sti(t4,gdp_ind,int_ind,:,:)-response_fc_in_sti(t3,gdp_ind,int_ind,:,:))',50),'-b');hold on;grid;
% plot(0:20,prctile(squeeze(response_fc_after_sti(t4,gdp_ind,int_ind,:,:)-response_fc_in_sti(t3,gdp_ind,int_ind,:,:))',error_lower),'--r');
% plot(0:20,prctile(squeeze(response_fc_after_sti(t4,gdp_ind,int_ind,:,:)-response_fc_in_sti(t3,gdp_ind,int_ind,:,:))',error_upper),'--r');
% title('(6)');
% fig = gcf;
% fig.PaperUnits = 'inches';
% fig.PaperPosition = [0 0 10 8];
% saveas(fig,strcat('graphs/Robustness2/irf_g_i.png'));           
% 
% 
% % irf of pi to i-------------------------------------------------------------------------------------------------------------
% figure;
% subplot(3,2,1)
% for t =1:length(a_all)
%     plot(0:20,prctile(squeeze(response_all(t,inf_ind,int_ind,:,:))',50));hold on;grid;
% end
% title('(1)');
% %axis([0 20 -0.8 0.8]);
% subplot(3,2,2)
% for t =1:length(a_before_fc)
%     if t==1
%         h1 = plot(0:20,prctile(squeeze(response_before_fc(t,inf_ind,int_ind,:,:))',50),'black');hold on;grid;
%     end
%     plot(0:20,prctile(squeeze(response_before_fc(t,inf_ind,int_ind,:,:))',50),'black')
% end
% 
% for t =1:length(a_fc_before_sti)
%     if t==1
%         h2 = plot(0:20,prctile(squeeze(response_fc_before_sti(t,inf_ind,int_ind,:,:))',50),'blue');hold on;grid;
%     end
%     plot(0:20,prctile(squeeze(response_fc_before_sti(t,inf_ind,int_ind,:,:))',50),'blue')
% end
% 
% for t =1:length(a_fc_in_sti)
%     if t==1
%         h3 = plot(0:20,prctile(squeeze(response_fc_in_sti(t,inf_ind,int_ind,:,:))',50),'yellow');hold on;grid;
%     end
%     plot(0:20,prctile(squeeze(response_fc_in_sti(t,inf_ind,int_ind,:,:))',50),'yellow')
% end
% 
% for t =1:length(a_fc_after_sti)
%     if t==1
%         h4 = plot(0:20,prctile(squeeze(response_fc_after_sti(t,inf_ind,int_ind,:,:))',50),'red');hold on;grid;
%     end
%     plot(0:20,prctile(squeeze(response_fc_after_sti(t,inf_ind,int_ind,:,:))',50),'red')
% end
% grid; set(gca,'xtick',[0 5 10 15 20]); hold on;%axis([0 20 -0.8 0.8]);
% title('(2)');
% lgd = legend([h1 h2 h3 h4],{'2001-2007','2008','2009-2010','2012-2014'});
% lgd.FontSize = 7;
% subplot(3,inf_ind,int_ind)
% plot(0:20,prctile(squeeze(response_before_fc(t1,inf_ind,int_ind,:,:))',50),'-b*');hold on;grid;
% plot(0:20,prctile(squeeze(response_fc_in_sti(t3,inf_ind,int_ind,:,:))',50),'-bd');
% plot(0:20,prctile(squeeze(response_fc_after_sti(t4,inf_ind,int_ind,:,:))',50),'-b+');
% legend('2006:Q3','2010:Q3','2012:Q3');
% title('(3)');
% subplot(3,2,4)
% plot(0:20,prctile(squeeze(response_fc_in_sti(t3,inf_ind,int_ind,:,:)-response_before_fc(t1,inf_ind,int_ind,:,:))',50),'-b');hold on;grid;
% plot(0:20,prctile(squeeze(response_fc_in_sti(t3,inf_ind,int_ind,:,:)-response_before_fc(t1,inf_ind,int_ind,:,:))',error_lower),'--r');
% plot(0:20,prctile(squeeze(response_fc_in_sti(t3,inf_ind,int_ind,:,:)-response_before_fc(t1,inf_ind,int_ind,:,:))',error_upper),'--r');
% title('(4)');
% subplot(3,2,5)
% plot(0:20,prctile(squeeze(response_fc_after_sti(t4,inf_ind,int_ind,:,:)-response_before_fc(t1,inf_ind,int_ind,:,:))',50),'-b');hold on;grid;
% plot(0:20,prctile(squeeze(response_fc_after_sti(t4,inf_ind,int_ind,:,:)-response_before_fc(t1,inf_ind,int_ind,:,:))',error_lower),'--r');
% plot(0:20,prctile(squeeze(response_fc_after_sti(t4,inf_ind,int_ind,:,:)-response_before_fc(t1,inf_ind,int_ind,:,:))',error_upper),'--r');
% title('(5)');
% subplot(3,2,6)
% plot(0:20,prctile(squeeze(response_fc_after_sti(t4,inf_ind,int_ind,:,:)-response_fc_in_sti(t3,inf_ind,int_ind,:,:))',50),'-b');hold on;grid;
% plot(0:20,prctile(squeeze(response_fc_after_sti(t4,inf_ind,int_ind,:,:)-response_fc_in_sti(t3,inf_ind,int_ind,:,:))',error_lower),'--r');
% plot(0:20,prctile(squeeze(response_fc_after_sti(t4,inf_ind,int_ind,:,:)-response_fc_in_sti(t3,inf_ind,int_ind,:,:))',error_upper),'--r');
% title('(6)');
% fig = gcf;
% fig.PaperUnits = 'inches';
% fig.PaperPosition = [0 0 10 8];
% saveas(fig,strcat('graphs/Robustness2/irf_pi_i.png'));           

% irf of g to m-------------------------------------------------------------------------------------------------------------
figure;
subplot(3,2,1)
for t =1:length(a_all)
    plot(0:20,prctile(squeeze(response_all(t,gdp_ind,mon_ind,:,:))',50));hold on;grid;
end
title('(1)');
%axis([0 20 -0.8 0.8]);
subplot(3,2,2)
for t =1:length(a_before_fc)
    if t==1
        h1 = plot(0:20,prctile(squeeze(response_before_fc(t,gdp_ind,mon_ind,:,:))',50),'black');hold on;grid;
    end
    plot(0:20,prctile(squeeze(response_before_fc(t,gdp_ind,mon_ind,:,:))',50),'black')
end

for t =1:length(a_fc_before_sti)
    if t==1
        h2 = plot(0:20,prctile(squeeze(response_fc_before_sti(t,gdp_ind,mon_ind,:,:))',50),'blue');hold on;grid;
    end
    plot(0:20,prctile(squeeze(response_fc_before_sti(t,gdp_ind,mon_ind,:,:))',50),'blue')
end

for t =1:length(a_fc_in_sti)
    if t==1
        h3 = plot(0:20,prctile(squeeze(response_fc_in_sti(t,gdp_ind,mon_ind,:,:))',50),'yellow');hold on;grid;
    end
    plot(0:20,prctile(squeeze(response_fc_in_sti(t,gdp_ind,mon_ind,:,:))',50),'yellow')
end

for t =1:length(a_fc_after_sti)
    if t==1
        h4 = plot(0:20,prctile(squeeze(response_fc_after_sti(t,gdp_ind,mon_ind,:,:))',50),'red');hold on;grid;
    end
    plot(0:20,prctile(squeeze(response_fc_after_sti(t,gdp_ind,mon_ind,:,:))',50),'red')
end
grid; set(gca,'xtick',[0 5 10 15 20]); hold on;%axis([0 20 -0.8 0.8]);
title('(2)');
lgd = legend([h1 h2 h3 h4],{'2001-2007','2008','2009-2010','2012-2014'});
lgd.FontSize = 7;
subplot(3,2,3)
plot(0:20,prctile(squeeze(response_before_fc(t1,gdp_ind,mon_ind,:,:))',50),'-b*');hold on;grid;
plot(0:20,prctile(squeeze(response_fc_in_sti(t3,gdp_ind,mon_ind,:,:))',50),'-bd');
plot(0:20,prctile(squeeze(response_fc_after_sti(t4,gdp_ind,mon_ind,:,:))',50),'-b+');
legend('2006:Q3','2010:Q3','2012:Q3');
title('(3)');
subplot(3,2,4)
plot(0:20,prctile(squeeze(response_fc_in_sti(t3,gdp_ind,mon_ind,:,:)-response_before_fc(t1,gdp_ind,mon_ind,:,:))',50),'-b');hold on;grid;
plot(0:20,prctile(squeeze(response_fc_in_sti(t3,gdp_ind,mon_ind,:,:)-response_before_fc(t1,gdp_ind,mon_ind,:,:))',error_lower),'--r');
plot(0:20,prctile(squeeze(response_fc_in_sti(t3,gdp_ind,mon_ind,:,:)-response_before_fc(t1,gdp_ind,mon_ind,:,:))',error_upper),'--r');
title('(4)');
subplot(3,2,5)
plot(0:20,prctile(squeeze(response_fc_after_sti(t4,gdp_ind,mon_ind,:,:)-response_before_fc(t1,gdp_ind,mon_ind,:,:))',50),'-b');hold on;grid;
plot(0:20,prctile(squeeze(response_fc_after_sti(t4,gdp_ind,mon_ind,:,:)-response_before_fc(t1,gdp_ind,mon_ind,:,:))',error_lower),'--r');
plot(0:20,prctile(squeeze(response_fc_after_sti(t4,gdp_ind,mon_ind,:,:)-response_before_fc(t1,gdp_ind,mon_ind,:,:))',error_upper),'--r');
title('(5)');
subplot(3,2,6)
plot(0:20,prctile(squeeze(response_fc_after_sti(t4,gdp_ind,mon_ind,:,:)-response_fc_in_sti(t3,gdp_ind,mon_ind,:,:))',50),'-b');hold on;grid;
plot(0:20,prctile(squeeze(response_fc_after_sti(t4,gdp_ind,mon_ind,:,:)-response_fc_in_sti(t3,gdp_ind,mon_ind,:,:))',error_lower),'--r');
plot(0:20,prctile(squeeze(response_fc_after_sti(t4,gdp_ind,mon_ind,:,:)-response_fc_in_sti(t3,gdp_ind,mon_ind,:,:))',error_upper),'--r');
title('(6)');
fig = gcf;
fig.PaperUnits = 'inches';
fig.PaperPosition = [0 0 10 8];
saveas(fig,strcat('graphs/Robustness2/irf_g_m.png'));           

% irf of pi to m-------------------------------------------------------------------------------------------------------------
figure;
subplot(3,2,1)
for t =1:length(a_all)
    plot(0:20,prctile(squeeze(response_all(t,inf_ind,mon_ind,:,:))',50));hold on;grid;
end
title('(1)');
%axis([0 20 -0.8 0.8]);
subplot(3,2,2)
for t =1:length(a_before_fc)
    if t==1
        h1 = plot(0:20,prctile(squeeze(response_before_fc(t,inf_ind,mon_ind,:,:))',50),'black');hold on;grid;
    end
    plot(0:20,prctile(squeeze(response_before_fc(t,inf_ind,mon_ind,:,:))',50),'black')
end

for t =1:length(a_fc_before_sti)
    if t==1
        h2 = plot(0:20,prctile(squeeze(response_fc_before_sti(t,inf_ind,mon_ind,:,:))',50),'blue');hold on;grid;
    end
    plot(0:20,prctile(squeeze(response_fc_before_sti(t,inf_ind,mon_ind,:,:))',50),'blue')
end

for t =1:length(a_fc_in_sti)
    if t==1
        h3 = plot(0:20,prctile(squeeze(response_fc_in_sti(t,inf_ind,mon_ind,:,:))',50),'yellow');hold on;grid;
    end
    plot(0:20,prctile(squeeze(response_fc_in_sti(t,inf_ind,mon_ind,:,:))',50),'yellow')
end

for t =1:length(a_fc_after_sti)
    if t==1
        h4 = plot(0:20,prctile(squeeze(response_fc_after_sti(t,inf_ind,mon_ind,:,:))',50),'red');hold on;grid;
    end
    plot(0:20,prctile(squeeze(response_fc_after_sti(t,inf_ind,mon_ind,:,:))',50),'red')
end
grid; set(gca,'xtick',[0 5 10 15 20]); hold on;%axis([0 20 -0.8 0.8]);
title('(2)');
lgd = legend([h1 h2 h3 h4],{'2001-2007','2008','2009-2010','2012-2014'});
lgd.FontSize = 7;
subplot(3,2,3)
plot(0:20,prctile(squeeze(response_before_fc(t1,inf_ind,mon_ind,:,:))',50),'-b*');hold on;grid;
plot(0:20,prctile(squeeze(response_fc_in_sti(t3,inf_ind,mon_ind,:,:))',50),'-bd');
plot(0:20,prctile(squeeze(response_fc_after_sti(t4,inf_ind,mon_ind,:,:))',50),'-b+');
legend('2006:Q3','2010:Q3','2012:Q3');
title('(3)');
subplot(3,2,4)
plot(0:20,prctile(squeeze(response_fc_in_sti(t3,inf_ind,mon_ind,:,:)-response_before_fc(t1,inf_ind,mon_ind,:,:))',50),'-b');hold on;grid;
plot(0:20,prctile(squeeze(response_fc_in_sti(t3,inf_ind,mon_ind,:,:)-response_before_fc(t1,inf_ind,mon_ind,:,:))',error_lower),'--r');
plot(0:20,prctile(squeeze(response_fc_in_sti(t3,inf_ind,mon_ind,:,:)-response_before_fc(t1,inf_ind,mon_ind,:,:))',error_upper),'--r');
title('(4)');
subplot(3,2,5)
plot(0:20,prctile(squeeze(response_fc_after_sti(t4,inf_ind,mon_ind,:,:)-response_before_fc(t1,inf_ind,mon_ind,:,:))',50),'-b');hold on;grid;
plot(0:20,prctile(squeeze(response_fc_after_sti(t4,inf_ind,mon_ind,:,:)-response_before_fc(t1,inf_ind,mon_ind,:,:))',error_lower),'--r');
plot(0:20,prctile(squeeze(response_fc_after_sti(t4,inf_ind,mon_ind,:,:)-response_before_fc(t1,inf_ind,mon_ind,:,:))',error_upper),'--r');
title('(5)');
subplot(3,2,6)
plot(0:20,prctile(squeeze(response_fc_after_sti(t4,inf_ind,mon_ind,:,:)-response_fc_in_sti(t3,inf_ind,mon_ind,:,:))',50),'-b');hold on;grid;
plot(0:20,prctile(squeeze(response_fc_after_sti(t4,inf_ind,mon_ind,:,:)-response_fc_in_sti(t3,inf_ind,mon_ind,:,:))',error_lower),'--r');
plot(0:20,prctile(squeeze(response_fc_after_sti(t4,inf_ind,mon_ind,:,:)-response_fc_in_sti(t3,inf_ind,mon_ind,:,:))',error_upper),'--r');
title('(6)');
fig = gcf;
fig.PaperUnits = 'inches';
fig.PaperPosition = [0 0 10 8];
saveas(fig,strcat('graphs/Robustness2/irf_pi_m.png'));           

        
%% 3. variance decomposition-------------------------------------------------------------------------------------
n_step_ahead = [1 2 4 8 16];
%response(T,n,n,step,M-N)
response=impulse_response(rsmall.A,rsmall.B,rsmall.expH,max(n_step_ahead),1:length(time));

%one step ahead variance
m_n = ndraw_graph;
[T,junk] = size(r.A);
var = zeros(T,r.n,r.n,max(n_step_ahead),m_n);
var_de = zeros(T,r.n,r.n,max(n_step_ahead),m_n);
for i = 1:m_n
    for t = 1:T
        theta_sum = zeros(r.n,r.n);  % redefine theta_sum for every t,i
        for step = 1:max(n_step_ahead)
             theta = squeeze(response(t,:,:,step,i)); %step theta
             theta_sum =  theta_sum + theta.^2;       %sum of theta^2 from 1 to step
             var(t,:,:,step,i) = theta_sum;
             
             %variance decomposition
             temp = sum(squeeze(var(t,:,:,step,i)),2);
             var_de(t,:,:,step,i) = squeeze(var(t,:,:,step,i))./repmat(temp,1,r.n);
        end
    end
end


%variance decomposition of gdp
figure;
i_graph = 1;
for i=1:length(n_step_ahead)
  for j= 1:r.n
    subplot(length(n_step_ahead),r.n,i_graph);
    plot(time,prctile(squeeze(var_de(:,gdp_ind,j,n_step_ahead(i),:))',50),'-b');hold on;grid;
    plot(time,prctile(squeeze(var_de(:,gdp_ind,j,n_step_ahead(i),:))',error_lower),'--r');
    plot(time,prctile(squeeze(var_de(:,gdp_ind,j,n_step_ahead(i),:))',error_upper),'--r');
    set(gca,'xtick',[2000 2009  2018]);axis([2000 2018 -0.1 1.1]);
    title(var_name_short(j));
%     if i~=1 & j ~= 1 & j~=3
%         axis([2000 2018 0 0.6]);
%     end
    i_graph = i_graph + 1;
   end
end
fig = gcf;
fig.PaperUnits = 'inches';
fig.PaperPosition = [0 0 8 8];
saveas(fig,strcat('graphs/Robustness2/var_de_g.png'));
   
  
figure;
i_graph = 1;
for i=1:length(n_step_ahead)
for j= 1:r.n
    subplot(length(n_step_ahead),r.n,i_graph);
    plot(time,prctile(squeeze(var_de(:,inf_ind,j,n_step_ahead(i),:))',50),'-b');hold on;grid;
    plot(time,prctile(squeeze(var_de(:,inf_ind,j,n_step_ahead(i),:))',error_lower),'--r');
    plot(time,prctile(squeeze(var_de(:,inf_ind,j,n_step_ahead(i),:))',error_upper),'--r');
    set(gca,'xtick',[2000  2009  2018]);axis([2000 2018 -0.1 1.1]);
    title(var_name_short(j));
%     if i~=1 & j ~= 2 & j~=1
%         axis([2000 2018 0 0.6]);
%     end
    i_graph = i_graph + 1;
end
end
fig = gcf;
fig.PaperUnits = 'inches';
fig.PaperPosition = [0 0 8 8];
saveas(fig,strcat('graphs/Robustness2/var_de_pi.png'));



              
%% 4. counterfactual analysis-------------------------------------------------------------------------------------
%what if there is no 4 trillion stimulus
%simulate the time series of 2008.75-2017.75 using the parameters of 2007.50
counter_start = 2008.75;
counter_end = 2017.75;
TT0 = (counter_start-time(1)+0.25)*4;
TT1 = (counter_end-time(1)+0.25)*4;
a = (2007.50-time(1)+0.25)*4;
res=counter(r.y,rsmall.B,rsmall.A,rsmall.expH,TT0,TT1,a);
time_counter = (counter_start:0.25:counter_end);
T_counter = (res.TT0:1:res.TT1);
figure;
subplot(2,1,1);
plot(time_counter,r.y(T_counter,1));hold on;
plot(time_counter,prctile(squeeze(res.YY(:,1,:))',50),'--b');
title('GDP Growth Rate');
plot(time_counter,prctile(squeeze(res.YY(:,1,:))',error_lower),'--r');
plot(time_counter,prctile(squeeze(res.YY(:,1,:))',error_upper),'--r');
lgd = legend('Actual','Counterfactural Median','16th Percentiles','84th Percentiles');
lgd.FontSize = 6;
lgd.Location = 'southwest';
subplot(2,1,2);
plot(time_counter,r.y(T_counter,1)'-prctile(squeeze(res.YY(:,1,:))',50),'-o');hold on;
plot(time_counter,r.y(T_counter,1)'-prctile(squeeze(res.YY(:,1,:))',error_lower),'--r');
plot(time_counter,r.y(T_counter,1)'-prctile(squeeze(res.YY(:,1,:))',error_upper),'--r');
title('Difference between Actual and Counterfactual Median');
fig = gcf;
fig.PaperUnits = 'inches';
fig.PaperPosition = [0 0 8 6];
saveas(fig,strcat('graphs/Robustness2/cf_g.png'));

figure;
subplot(2,1,1);
plot(time_counter,r.y(T_counter,2));hold on;
plot(time_counter,prctile(squeeze(res.YY(:,2,:))',50),'--b')
title('Inflation Rate');
plot(time_counter,prctile(squeeze(res.YY(:,2,:))',error_lower),'--r');
plot(time_counter,prctile(squeeze(res.YY(:,2,:))',error_upper),'--r');
lgd = legend('Actual','Counterfactural Median','16th Percentiles','84th Percentiles');
lgd.FontSize = 7;
subplot(2,1,2);
plot(time_counter,r.y(T_counter,2)'-prctile(squeeze(res.YY(:,2,:))',50),'-o'); hold on;
plot(time_counter,r.y(T_counter,2)'-prctile(squeeze(res.YY(:,2,:))',error_lower),'--r');
plot(time_counter,r.y(T_counter,2)'-prctile(squeeze(res.YY(:,2,:))',error_upper),'--r');
title('Difference between Actual and Counterfactual Median');
fig = gcf;
fig.PaperUnits = 'inches';
fig.PaperPosition = [0 0 8 6];
saveas(fig,strcat('graphs/Robustness2/cf_pi.png'));

