function [irf_save,Atilde_save] = sign_identification4(BB,AA,HH,nstep,a)

% BB is the VAR parameter
% AA is the correlation part of variance
% HH is the Sigma
% nstep is the horizon of irf
% a is the specific time periods for irf

%this function generate the structrual parameter of VAR based on 
%sign restrictions
%yt = c + B1 yt-1 + ... +Bp yt-p + A^-1 H et   et~N(0,I)
%the structrual form is:
%A~ yt = A~ c + A~ B1 yt-1 + ... + A~ Bp yt-p + et
%where A~^-1 = A^-1*H*U and U is an athornormal matrix that U*U'=I

%The restriction is a mixture of zero short-run restriction and sign
%restriction. We partition the four variable var to two parts n=n1+n2. And
%n1 = 2,n2=2. y=[g pi | i m]. It is assumed that [g pi] do not respond to
%[i m] contemporaneously.

%The cholesky decomposition is Omega = A^-1 H H' A^-1'
%We have sign restriction only for the lower two-variable part. So we draw
%a random matrix U(2 x 2) that U*U'=I_2 and let the muliplication matrix be
%U_ =[I_2 0
%     0   U]
%Then A~^-1 = A^-1*H*U_

%the sign restrictions are:
%                     interest rate shock     money growth rate shock                          -
%GDP growth rate      -                       +
%inflation            -                       +
 
nrep    = size(HH,3);   % Number of iteration
nrot    = 100;          % Number of rotations

n       = size(HH,2);
T       = size(HH,1);
lags = (size(BB,2)/n-1)/n;
g_ind=1;pi_ind=2;i_ind=3;m_ind=4;                        %indicator of gdp, money

k2 = 2;                                  %the number of sign restriction equations
k1 = n - k2;
irf_save = zeros(length(a),n,n,nstep,nrep);
Atilde_save = zeros(T,n,n,nrot,nrep);
B_lag=zeros(n,n,lags);
for t=1:length(a) 
    t
    
    
    if t==1
        mU = zeros(n,n,nrot,nrep);  %use the same U for every t
        for i=1:nrep
            i
        ind=1;
        irf_store = zeros(n,n,nstep,nrot);
        %iter = 0;
        while ind<=nrot
            
            [U,R]  = qr(randn(k2,k2));
            for j=1:k2
                if R(j,j)<0
                    U(:,j)=-U(:,j);
                end;
            end;
            
%             %sign restriction on A
%             if U(1,2) >= 0
%                 continue;
%             end
                
            
            
            
            
            
            temp = eye(n);
            temp(k1+1:end,k1+1:end) = U;
            U = temp;
            Atilde = tria(AA(a(t),:,i))\diag(HH(a(t),:,i))*U;  %smat

           
            
            %get the B for impulsdtrf=====================================
            for i_lag = 1:lags
                  for i_eq = 1:n
                        B_lag(i_eq,:,i_lag)=BB(a(t),(1+(lags*n+1)*(i_eq-1)+n*(i_lag-1)+1):(1+(lags*n+1)*(i_eq-1)+n*(i_lag-1)+n),i);
                  end
            end
            %===============================================================
            
              irf=impulsdtrf(B_lag,Atilde,nstep);
%              irf_store(:,:,:,ind) = irf;
%              ind = ind+1;
            % Identification here involves dynamic sign restrictions
           if squeeze(irf(m_ind,i_ind,1))<0  && squeeze(irf(m_ind,m_ind,1))>0 && squeeze(irf(i_ind,i_ind,1))>0 &&...
                   squeeze(irf(m_ind,i_ind,2))<0  && squeeze(irf(m_ind,m_ind,2))>0 && squeeze(irf(i_ind,i_ind,2))>0 &&...
                   squeeze(irf(m_ind,i_ind,3))<0  && squeeze(irf(m_ind,m_ind,3))>0 && squeeze(irf(i_ind,i_ind,3))>0 &&...
                   squeeze(irf(m_ind,i_ind,4))<0  && squeeze(irf(m_ind,m_ind,4))>0 && squeeze(irf(i_ind,i_ind,4))>0 &&...
                   squeeze(irf(m_ind,i_ind,5))<0  && squeeze(irf(m_ind,m_ind,5))>0 && squeeze(irf(i_ind,i_ind,5))>0
           %if squeeze(irf(g_ind,m_ind,5))>0 && squeeze(irf(g_ind,i_ind,5))<0
           %if squeeze(irf(i_ind,m_ind,1))<0  && squeeze(irf(i_ind,m_ind,2))<0  && squeeze(irf(i_ind,m_ind,3))<0  && squeeze(irf(i_ind,m_ind,4))<0 &&...
               %squeeze(irf(m_ind,i_ind,1))<0 && squeeze(irf(m_ind,i_ind,2))<0 && squeeze(irf(m_ind,i_ind,3))<0 && squeeze(irf(m_ind,i_ind,4))<0 
            %if squeeze(irf(i_ind,m_ind,5))<0 && squeeze(irf(m_ind,i_ind,5))<0
               irf_store(:,:,:,ind) = irf;
               mU(:,:,ind,i) = U;
               Atilde_save(t,:,:,ind,i) = Atilde;
               ind = ind+1; %increase 1 when one draw is successful until nrot
            end;
            %iter=iter+1;
          
        end;
        
        %after  100 possible Q, compute the median irf as the
        %sign-restricted
        %irf======================================================================
        for variable=1:n
            for shock=1:n
                for step=1:nstep
                    irf_save(t,variable,shock,step,i)=mean(squeeze(irf_store(variable,shock,step,:)));
                end
            end
        end
        %========================================================================
       end
 %-----------------------------------------------------------------------------------------
    else %for other t, use the same U as t=1 to generate the irf
 %--------------------------------------------------------------------------------------
        for i=1:nrep
            irf_store = zeros(n,n,nstep,nrot);
            for ind = 1:nrot
                 U = squeeze(mU(:,:,ind,i));
                 Atilde = tria(AA(a(t),:,i))\diag(HH(a(t),:,i))*U;  %smat
                 Atilde_save(t,:,:,ind,i) = Atilde;
                  %get the B for impulsdtrf=====================================
                for i_lag = 1:lags
                    for i_eq = 1:n
                        B_lag(i_eq,:,i_lag)=BB(a(t),(1+(lags*n+1)*(i_eq-1)+n*(i_lag-1)+1):(1+(lags*n+1)*(i_eq-1)+n*(i_lag-1)+n),i);
                    end
                end
                %===============================================================
                
                irf=impulsdtrf(B_lag,Atilde,nstep);
                irf_store(:,:,:,ind) = irf;
            end
            %after  100 possible Q, compute the median irf as the
            %sign-restricted
            %irf======================================================================
            for variable=1:n
                for shock=1:n
                    for step=1:nstep
                        irf_save(t,variable,shock,step,i)=mean(squeeze(irf_store(variable,shock,step,:)));
                    end
                end
            end
            %========================================================================
        end
        
    end
end
        