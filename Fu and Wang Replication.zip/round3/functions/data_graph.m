%display the four series

n = size(data,2)-1;
figure;
for i = 1:n
    subplot(4,1,i);
    plot(data(:,1),data(:,1+i),'linewidth',1.5);
    if i==3;
        title(strcat(var_name(i),' (7 Day Repo Rate)'));
    elseif i==4;
        title(strcat(var_name(i),' (M2)'));
    else
    title(var_name(i));
    end
    yMin = -5; yMax = 20;
    if i == 2
        yMax = 10;
    elseif i==3
        yMin = 0;yMax =15;
    elseif i==4
        yMin = 5;yMax = 30;
    end
    axis([1996 2018 yMin yMax]);
    grid;hold on;
    gray = [0.8 0.8 0.8];
    patch([2007.75 2009 2009 2007.75],[yMin yMin yMax yMax],gray,'EdgeColor','none');
    alpha(0.5); 
    patch([2008.75 2010.75 2010.75 2008.75],[yMin yMin yMax yMax],[0.2 0.2 0.2],'EdgeColor','none');
    alpha(0.5); 
end
fig = gcf;
fig.PaperUnits = 'inches';
fig.PaperPosition = [0 0 8 8];
saveas(fig,'graphs/dataPlot.png');

std_all = std(data(:,2:5));
std_percent_all = std_all./mean(data(:,2:5));
std_percent_09b = std(data(1:(2009-1996+0.25)*4,2:5))./mean(data(1:(2009-1996+0.25)*4,2:5));
std_percent_09a = std(data((2009-1996+0.25)*4:end,2:5))./mean(data((2009-1996+0.25)*4:end,2:5));
std_matrix = [std_percent_all;std_percent_09b;std_percent_09a];
disp(std_matrix);
csvwrite('table1.csv',std_matrix);



% %display i and m
% figure;
% yyaxis left
% plot(data(:,1),data(:,int_ind+1),'-*');hold on;
% yyaxis right
% plot(data(:,1),data(:,mon_ind+1),'-o');
% legend([var_name(int_ind),var_name(mon_ind)]);
% gray = [0.8 0.8 0.8];
% patch([2007.75 2009 2009 2007.75],[0 0 30 30],gray,'EdgeColor','none');
% alpha(0.5); 

im_corr_all = corrcoef(data(:,int_ind+1),data(:,mon_ind+1));
im_corr_09b = corrcoef(data(1:(2009-1996+0.25)*4,int_ind+1),data(1:(2009-1996+0.25)*4,mon_ind+1));
im_corr_09a = corrcoef(data((2009-1996+0.25)*4:end,int_ind+1),data((2009-1996+0.25)*4:end,mon_ind+1));
corr = [im_corr_all(1,2) im_corr_09b(1,2) im_corr_09a(1,2)];
disp(corr);
