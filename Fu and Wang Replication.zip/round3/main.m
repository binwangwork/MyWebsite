close all;
clear all;
clc;

addpath('functions')


% load data
data = csvread('china_macrodata.csv',1,0);

var_name = {'GDP Growth Rate' 'Inflation Rate' 'Interest Rate' 'Money Growth Rate'};
var_name_short = {'g','\pi','i','m'};
gdp_ind = 1;
inf_ind = 2;
int_ind = 3;
mon_ind = 4;

%data_graph;

T0 = 20;
nrep=10000;
nburn=2000;
nthin=1; % thinning parameter (choose 1 if want to use all draws for constructing the final graphs;
nstep = 21;
error_lower = 16;
error_upper = 84;

r=tvsvar(data,T0,nrep);



NewGraphs;

% Robustness1;
% Robustness2;
% Robustness3;
% Robustness4;
