Empirical part:

In File "SVM", run "estimatemodel.m" and then get estimations and the impulse response figure of SVM-VAR model.


Theoretical part:

With Dynare 4.5.7, run "Oil.mod" in File "DSGE" and then get the impulse response figure of the DSGE model.
