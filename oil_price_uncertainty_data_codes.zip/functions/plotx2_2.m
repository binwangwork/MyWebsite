function hh=plotx2(t,y)
set(gcf,'DefaultAxesColorOrder',[0.8 0.1 0.1;1 0 0;1 0 0;0 0 1]);
cu=y(:,2);
cl=y(:,3);

h=t;
%h=h;
hh=fill([h(1); h(1:end); flipud([h(1:end); h(end)])],[cu(1); cl(1:end); flipud([cu(1:end); cl(size(cl,1))])],'b--');
% matlab中的flipud函数实现矩阵的上下翻转。flipud(X)实现了矩阵X的上下翻转。

%set(hh,'edgecolor',[0.6 0.75 0.75]);
%set(hh,'edgecolor','k');
set(hh,'facecolor',[1 1 1]);

hold on;

 plot(h,y(:,1),'b','LineWidth',2);  %median IRF

hold on;
zz=zeros(size(y,1),1);
plot(h,zz,'k:'); % x aix
