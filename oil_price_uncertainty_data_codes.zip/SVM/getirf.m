clc;clear all;
addpath('../functions');
load priors
horizon1=20;
scale=1;
pos=2;


load(sfile,'amatsave','bsave','fsave','qsave','hsave');
fsize=100;
REPSx=100;
irfmat=zeros(fsize,horizon1,N*3+1);
for jgibbs=1:fsize
    iamat=squeeze(amatsave(jgibbs,:,:));
    beta2=bsave(jgibbs,:,:);
    fbig=squeeze(fsave(jgibbs,:,:))';
    Qbig=squeeze(qsave(jgibbs,:,:))';
    hlast=squeeze(hsave(jgibbs,:,:));
    A0=iamat';
    betaf1=reshape(fbig,N+(N*LV+1),N);
    Fmat=betaf1;
    
    Qmat=reshape(Qbig,N,N);
    mumat=zeros(N,1);

    FF=comp(beta2,N,L,EX);
    varcoef=reshape(beta2,N*L+EX,N);
    
    
    
    jgibbs
    [ ir,hir,vir,dir ] = getirfT_0( L,LH,LV,N,horizon1,Fmat,Qmat,varcoef,iamat,A0,REPSx,y,hlast(1:end,:),FF,scale,pos);
    tmp=[ir hir vir dir];
    
    irfmat(jgibbs,:,:)=tmp;
    
       
end
save('irftestnew','irfmat');
% endogenous variable names
vnames{1}='Oil production';
vnames{2}='Oil price';
vnames{3}='Real activity';

% log volatility names
vnames{4}='Oil production volatility';
vnames{5}='Oil price volatility';
vnames{6}='Real activity volatility';

% level shock names
snames{1}='e_{Oil production}';
snames{2}='e_{Oil price}';
snames{3}='e_{Real activity}';

% volatility shock names
hnames{1}='v_{Oil production}';
hnames{2}='v_{Oil price}';
hnames{3}='v_{Real activity}';

hh=0:horizon1-1;

figure(2)

tmp=prctile(irfmat,[50 16 84],1);
j=2;
index=[ 1 2 3 8];
for i=1:3
    subplot(2,2,i)
    tmpx=squeeze(tmp(:,:,index(i)));
    plotx2_2(hh',tmpx');
    %ylabel(hnames{j});
    title(vnames{i});
    axis tight
    %grid on
    
end
for i=4
    subplot(2,2,i)
    tmpx=squeeze(tmp(:,:,index(i)));
    plotx2_2(hh',tmpx');
    %ylabel(hnames{j});
    title(vnames{5});
    axis tight
    %grid on
    
end
