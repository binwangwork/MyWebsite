function [para,ss]= dsgess

PI_ss = 1.0056;
R_ss = 1.0068;
delta=0.025;
epsilon = 10;
alppha =0.5;

u_ss=1;
l_ss=0.33333333;

betta = PI_ss/R_ss;

q_ss=1;

r_ss=1/betta-(1-delta);

thetap =0.75;

gamma = 2;

Phi=0;

h=0.6;

mc_ss=(epsilon-1)/epsilon;

PIstar_ss=1;

vp_ss=1;

ld_ss=l_ss;

rho_oil = 0.0672365;
p_oilbar = 0.09399;

temp_wage = (p_oilbar/(alppha*rho_oil))^(alppha*rho_oil)*(r_ss/(alppha*(1-rho_oil)))^(alppha*(1-rho_oil));
w_ss = (mc_ss/temp_wage)^(1/(1-alppha))*(1-alppha);

k_ss = w_ss*ld_ss/r_ss*alppha*(1-rho_oil)/(1-alppha);

oil_ss = w_ss*ld_ss/p_oilbar*alppha*rho_oil/(1-alppha);

yd_ss=((oil_ss^rho_oil*k_ss^(1-rho_oil))^alppha*ld_ss^(1-alppha)-Phi);

x_ss=delta*k_ss;

oilvalue = p_oilbar*oil_ss;
gdp_ss = yd_ss - oilvalue;
oil2gdp = oilvalue/gdp_ss;

oil2capital=oil_ss/k_ss;
c_ss = gdp_ss - x_ss;

lambda_ss=(1-h*betta)*(1-h)^(-1)/c_ss;

psiL =w_ss*lambda_ss/(l_ss^gamma);

g1_ss=lambda_ss*mc_ss*yd_ss/(1-betta*thetap);
g2_ss=epsilon/(epsilon-1)*g1_ss;

thetaw =0;
eta= 10;
gamma2=0.0698;
gamma1=r_ss;
f_ss = 0;
f2_ss = 0;
PIstarw_ss=1;vw_ss=1;wstar_ss=1;

para=[delta; epsilon; alppha; betta; gamma1; thetap; thetaw; eta;
    gamma; gamma2; Phi; h; rho_oil; p_oilbar; psiL];
ss=[PI_ss; R_ss; u_ss; l_ss; q_ss; r_ss; mc_ss; w_ss; PIstar_ss; PIstarw_ss;
    vp_ss; vw_ss; ld_ss; wstar_ss; k_ss; oil_ss; yd_ss; x_ss; gdp_ss; c_ss;
    lambda_ss; f_ss; f2_ss; g1_ss; g2_ss];

end
