function response=impulse_response(AA,BB,HH,n,lags,nstep,M,N,a)
% computes the irf of different dates
% a is a vector which indicates the starting point of the dates
% AA, BB,HH are time varying parameter draws
% n is the number of variables
% lags is the number of lags
% nstep is the number of horizons of irf
% M is number os draws
% N is the burnin number of draws


T=size(BB,1);
d=size(BB,2);
[junk T_slot]=size(a);
a=((a-2001.25))*4;
MM=M-N;

  

smat=zeros(n,n);
B_lag=zeros(n,n,lags);
response=zeros(T_slot,n,n,nstep,MM);
for i=1:MM
for t=1:T_slot
    %--------means of all time H
     %H=diag(mean((HH(:,:)),1)); %%HH is already a mean accross nrep draws; H is a mean accross T observations
     %smat=(tria(mean(squeeze(AA(a(t):a(t),:,i+N)),1))\H)';  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %--------time t H
    smat=(tria(mean(squeeze(AA(a(t):a(t),:,i+N)),1))\diag(mean(squeeze(HH(a(t):a(t),:,i+N)),1)))'; %use time t H for irf
    for i_lag = 1:lags
        for i_eq = 1:n
           B_lag(i_eq,:,i_lag)=mean(BB(a(t):a(t),(1+(lags*n+1)*(i_eq-1)+n*(i_lag-1)+1):(1+(lags*n+1)*(i_eq-1)+n*(i_lag-1)+n),i+N) ,1);
        end
    end
    response(t,:,:,:,i)=impulsdtrf(B_lag(:,:,:),smat,nstep);
end
end

% for i_lag = 1:lags
%         for i_eq = 1:n
%           disp((1+(lags*n+1)*(i_eq-1)+n*(i_lag-1)+1):(1+(lags*n+1)*(i_eq-1)+n*(i_lag-1)+n))
%         end
% end
          
end
    




