%Forecast the real interest rate in 20 quarters' horizon


rsmall.B=r.B(:,:,[int:int:end]);
rsmall.A=r.A(:,:,[int:int:end]);
rsmall.H=r.H(:,:,[int:int:end]);
rsmall.expH = exp(rsmall.H);     %the original Sigma matrix

rsmall.M=size(rsmall.B,3);
rsmall.N=round(N/int);
time=[2001.50:.25:2017.75];

%the best forecast is E_t y_(t+i) = B^i y_t
forecast_step = 20;
a_all = [2001.50:0.25:2017.75];

forecast = forecast_y(r.y,rsmall.B,r.n,lags,forecast_step,rsmall.M,rsmall.N,a_all);
natural_rate = prctile(squeeze(forecast(:,3,forecast_step,:))',50);
%benchmark
bm = natural_rate;
bm16 = prctile(squeeze(forecast(:,3,forecast_step,:))',16);
bm84 = prctile(squeeze(forecast(:,3,forecast_step,:))',84);

figure;
h1=plot(time,r.y(:,3),'r','LineWidth',1);hold on;
h2=plot(time,bm,'-b','LineWidth',1);
h3 = plot(time,bm16,'--b');
plot(time,bm84,'--b');
lgd = legend([h1 h2 h3],{'Real Interest Rate','Median Natural Rate of Interest','16/84 Percentile'});
lgd.Location = 'northwest';
grid;axis([2000 2018 -4 6]);
%add financial crisis period
% Add a patch
gray = [0.8 0.8 0.8];
patch([2007.75 2009 2009 2007.75],[-4 -4 6 6],gray);
alpha(0.3);
fig = gcf;
fig.PaperUnits = 'inches';
fig.PaperPosition = [0 0 8 4];
saveas(fig,'natural_rate.png');

figure;
yyaxis left
plot(time,bm,'--ob'); hold on;grid;
yyaxis right
plot(time,r.y(:,1),'--*r');
legend('Natural Rate of Interest','GDP Growth Rate');
fig = gcf;
fig.PaperUnits = 'inches';
fig.PaperPosition = [0 0 8 4];
saveas(fig,'nr_g.png');


%disp(['average rate ' ' standard dev.']);
%disp([mean(natural_rate) std(natural_rate)]);
nr_median = natural_rate;
nr_5percentile = prctile(squeeze(forecast(:,3,forecast_step,:))',5);
nr_95percentile = prctile(squeeze(forecast(:,3,forecast_step,:))',95);
savedata = [time' nr_median' nr_5percentile' nr_95percentile'];
xlswrite('natural_rate.xlsx',savedata,1);
