




%case 1, excluding money growth rate
y=y(:,1:3);
T0A=[2 3];
T0H=4;
r=tvsvar(y,lags,T0,T0B,T0A,T0H,kB,kA,kH,M);


rsmall.B=r.B(:,:,[int:int:end]);
rsmall.A=r.A(:,:,[int:int:end]);
rsmall.H=r.H(:,:,[int:int:end]);
rsmall.expH = exp(rsmall.H);     %the original Sigma matrix

rsmall.M=size(rsmall.B,3);
rsmall.N=round(N/int);
time=[2001.50:.25:2017.75];

%the best forecast is E_t y_(t+i) = B^i y_t
forecast_step = 20;
a_all = [2001.50:0.25:2017.75];

forecast = forecast_y(r.y,rsmall.B,r.n,lags,forecast_step,rsmall.M,rsmall.N,a_all);
natural_rate = prctile(squeeze(forecast(:,3,forecast_step,:))',50);
case1 = natural_rate;

%case 2, replace chibor7d
data = csvread('china_macrodata_chibor.csv',1,0);

ydata = data(:,2:5);
yearlab = data(:,1);
y=ydata;

T0A=[2 3 4];          %DEGREEE OF FREEDOM IN THE INVERSE WISHORT DISTRIBUTION OF SIGMA_ALPHA
T0H=5;                %DEGREEE OF FREEDOM IN THE INVERSE WISHORT DISTRIBUTION OF SIGMA_H
r=tvsvar(y,lags,T0,T0B,T0A,T0H,kB,kA,kH,M);

rsmall.B=r.B(:,:,[int:int:end]);
rsmall.A=r.A(:,:,[int:int:end]);
rsmall.H=r.H(:,:,[int:int:end]);
rsmall.expH = exp(rsmall.H);     %the original Sigma matrix

rsmall.M=size(rsmall.B,3);
rsmall.N=round(N/int);
time=[2001.50:.25:2017.75];

%the best forecast is E_t y_(t+i) = B^i y_t
forecast_step = 20;
a_all = [2001.50:0.25:2017.75];

forecast = forecast_y(r.y,rsmall.B,r.n,lags,forecast_step,rsmall.M,rsmall.N,a_all);
natural_rate = prctile(squeeze(forecast(:,3,forecast_step,:))',50);
case2 = natural_rate;

figure;
plot(time,bm,'--black*');hold on;
plot(time,case1,'--ro');
plot(time,case2,'--bd');
axis([2000 2018 -1 4]);grid;
legend('Benchmark','Excluding Money Growth Rate','Substituting for 7-Day CHIBOR Rate');
gray = [0.8 0.8 0.8];
patch([2007.75 2009 2009 2007.75],[-1 -1 4 4],gray);
alpha(0.3);
fig = gcf;
fig.PaperUnits = 'inches';
fig.PaperPosition = [0 0 8 4];
saveas(fig,'robust.png');

