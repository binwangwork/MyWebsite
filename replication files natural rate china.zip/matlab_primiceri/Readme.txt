The program files are built on the TVP-VAR-SV matlab files of Del Negro and Primiceri (2015). 

Run main.m to get all 10 figures in the paper Wang and Fu (2018).