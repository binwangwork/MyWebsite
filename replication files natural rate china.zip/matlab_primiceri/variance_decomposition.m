%variance decomposition
%yt = theta0*et + theta1*et+1 + ...
%theta_i is the impulse response function of et with horizon i
%Var_n = sum_0^n thetai*thetai' n step ahead variance
time=[2001.50:.25:2017.75]; %time in tvp-var
n_step_ahead = [4 8 12 16];
%response(T,n,n,step,M-N)
response=impulse_response(rsmall.A,rsmall.B,rsmall.expH,r.n,lags,max(n_step_ahead),rsmall.M,rsmall.N,time);

%one step ahead variance
m_n = rsmall.M-rsmall.N;
[T,junk] = size(r.A);
var = zeros(T,r.n,r.n,max(n_step_ahead),m_n);
var_de = zeros(T,r.n,r.n,max(n_step_ahead),m_n);
for i = 1:m_n
    for t = 1:T
        theta_sum = zeros(r.n,r.n);  % redefine theta_sum for every t,i
        for step = 1:max(n_step_ahead)
             theta = squeeze(response(t,:,:,step,i)); %step theta
             theta_sum =  theta_sum + theta.^2;       %sum of theta^2 from 1 to step
             var(t,:,:,step,i) = theta_sum;
             
             %variance decomposition
             temp = sum(squeeze(var(t,:,:,step,i)),2);
             var_de(t,:,:,step,i) = squeeze(var(t,:,:,step,i))./repmat(temp,1,r.n);
        end
    end
end


%variance decomposition of gdp
gdp_ind = 1;
inf_ind = 2;
figure;
for i = 1:length(n_step_ahead)
   step_no = n_step_ahead(i);
   subplot(2,2,i);
   plot(time,prctile(squeeze(var_de(:,gdp_ind,1,step_no,:))',50),'-b');hold on;
   plot(time,prctile(squeeze(var_de(:,gdp_ind,2,step_no,:))',50),'-.b');
   plot(time,prctile(squeeze(var_de(:,gdp_ind,3,step_no,:))',50),'--b');
   plot(time,prctile(squeeze(var_de(:,gdp_ind,4,step_no,:))',50),':b');
   lgd = legend('g','\pi','i','m');set(gca,'xtick',[2000 2005 2009 2014 2018]);axis([2000 2018 0 1]);
   title(strcat({'Horizon: '}, num2str(n_step_ahead(i)), {' Quarters'}));
   lgd.FontSize = 7;
end
fig = gcf;
fig.PaperUnits = 'inches';
fig.PaperPosition = [0 0 8 6];
saveas(fig,strcat('var_de_g.png'));
   
figure;  
for i = 1:length(n_step_ahead)
   step_no = n_step_ahead(i);
   subplot(2,2,i);
   plot(time,prctile(squeeze(var_de(:,inf_ind,1,step_no,:))',50),'-b');hold on;
   plot(time,prctile(squeeze(var_de(:,inf_ind,2,step_no,:))',50),'-.b');
   plot(time,prctile(squeeze(var_de(:,inf_ind,3,step_no,:))',50),'--b');
   plot(time,prctile(squeeze(var_de(:,inf_ind,4,step_no,:))',50),':b');
   axis([2000 2018 0 1]);set(gca,'xtick',[2000 2005 2009 2014 2018]);
   lgd = legend('g','\pi','i','m');
   lgd.Location = 'northwest';
   lgd.FontSize = 7;
   title(strcat({'Horizon: '}, num2str(n_step_ahead(i)), {' Quarters'}));
end
fig = gcf;
fig.PaperUnits = 'inches';
fig.PaperPosition = [0 0 8 6];
saveas(fig,strcat('var_de_pi.png'));
    
    