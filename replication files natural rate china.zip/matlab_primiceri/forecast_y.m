function forecast=forecast_y(y,BB,n,lags,forecast_step,M,N,a)
% computes the forecast_step ahead forecast of different dates
% y is the observation from the start of the estimated sample
% a is a vector which indicates the starting point of the dates
% BB is time varying parameter draws
% n is the number of variables
% lags is the number of lags
% forecast_step is the number of horizons of forecast
% M is number os draws
% N is the burnin number of draws


T=size(BB,1);
d=size(BB,2);
[junk T_slot]=size(a);
a=((a-2001.25))*4;
MM=M-N;


B_lag=zeros(n,n,lags);
B0 = zeros(n,1);
forecast=zeros(T_slot,n,forecast_step,MM);
for i=1:MM
for t=1:T_slot
    for i_lag = 1:lags
        for i_eq = 1:n
           B0(i_eq) = mean(BB(a(t):a(t),(lags*n+1)*(i_eq-1)+1,i+N),1);
           B_lag(i_eq,:,i_lag)=mean(BB(a(t):a(t),(1+(lags*n+1)*(i_eq-1)+n*(i_lag-1)+1):(1+(lags*n+1)*(i_eq-1)+n*(i_lag-1)+n),i+N) ,1);
        end
    end
    forecast(t,:,:,i)=simulate_y(y(t,:)',B0,B_lag,forecast_step);
end
end