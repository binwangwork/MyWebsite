function res=counter(y,B,A,H,n,lags,M,N,target_start,target_end,a)
%y should be the data of tvp-var and the time should be the same as B,A,H
%target_start,target_end are the time period we want to do the
%counterfactual analysis
%a is the time we want to use as the time of parameter values used in
%counterfactual analysis


TT0=(target_start-2001.25)*4;
TT1=(target_end-2001.25)*4;
a=((a-2001.25))*4;
TT=TT1-TT0+1; %total number of quarters during the analysis
MM=M-N;
z=y;

YY=zeros(TT,n,MM);  %simulated data

%store parameter value for the target period T0-T1
BB=zeros(n,n,lags);
CON = zeros(n,1);
AA=zeros(n,n);
HH=zeros(n,n);
se=zeros(n,1);

%as if parameter values for the period a 
BBB=zeros(n,n,lags);
CONCON = zeros(n,1);
AAA=zeros(n,n);
HHH=zeros(n,n);


ycf=zeros(TT+lags,n);
ycf(1:lags,:)=z(TT0-lags:TT0-1,:);



for i=1:MM
    for t=TT0:TT1
        %-----------------------------------------------------------------------------------------------
        %GET THE SHOCK VALUES OF PERIOD T0-T1
        %------------------------------------------------------------------------------------------------
        
        %get B0,B1 and B2
        for i_lag = 1:lags            
           for i_eq = 1:n
               BB(i_eq,:,i_lag)=B(t,(1+(lags*n+1)*(i_eq-1)+n*(i_lag-1)+1):(1+(lags*n+1)*(i_eq-1)+n*(i_lag-1)+n),i+N);
               CON(i_eq,1) = B(t,1+(lags*n+1)*(i_eq-1),i+N);
           end
        end
        AA=tria(squeeze(A(t,:,i+N)));
        HH=diag(squeeze(H(t,:,i+N)));
        se=HH\AA*(z(t,:)'-BB(:,:,1)*z(t-1,:)'-BB(:,:,2)*z(t-2,:)'-CON);
        
        %-------------------------------------------------------------------------------------------------
        %GET THE PARAMETER VALUES OF PRE-CRISIS
        %-----------------------------------------------------------------------------------------------
        for i_lag = 1:lags            
           for i_eq = 1:n
               BBB(i_eq,:,i_lag)=mean(B(a(1)-8:a(1),(1+(lags*n+1)*(i_eq-1)+n*(i_lag-1)+1):(1+(lags*n+1)*(i_eq-1)+n*(i_lag-1)+n),i+N),1);
               CONCON(i_eq,1) = mean(B(a(1)-8:a(1),1+(lags*n+1)*(i_eq-1),i+N),1);
           end
        end
        AAA=tria(squeeze(mean(A(a(1)-8:a(1),:,i+N),1)));
        HHH=diag(squeeze(mean(H(a(1)-8:a(1),:,i+N),1)));
        
        ycf(t-TT0+1+2,:)=(BBB(:,:,1)*ycf(t-1-TT0+1+2,:)'+BBB(:,:,2)*ycf(t-2-TT0+1+2,:)'+CONCON+AAA\HHH*se)';
    end
    YY(:,:,i)=ycf(lags+1:end,:);
end

res.YY=YY;
res.a = a;
res.start = target_start;
res.end = target_end;


end
