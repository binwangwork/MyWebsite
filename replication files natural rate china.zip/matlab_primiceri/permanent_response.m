% This function is to compute the permanent response of the policy of
% i_policy to the 1% permanent increase of the variable i_private

function II = permanent_response(AA,BB,n,lags,M,N,i_policy,i_private,horizon)
%A,B,H are time varying parameters 
%n is the number of variables used in VAR
%M is the whole sample number
%N is the burn-in sample number
%i_policy is the index of the policy variable
%i_private is the index of the private varaible

MM=M-N;
T=size(BB,1);
B_lag=zeros(T,n,n,lags); %B_1,B_2 ... B_lags
BB_lag = zeros(T,n,n,lags); %BB_lag = A*B_lag
A_matrix = zeros(T,n,n);   %transform vector alpha to A
max_horizon = max(horizon);      %largest horizon to record
I= zeros(T,max_horizon);
II=zeros(T,length(horizon),MM);      %record the ps of horizon


for i=1:MM
    for t=1:T
        %record B_1,...,B_lags
        for i_lag = 1:lags
          for i_eq = 1:n
              B_lag(t,i_eq,:,i_lag)=BB(t,(1+(lags*n+1)*(i_eq-1)+n*(i_lag-1)+1):(1+(lags*n+1)*(i_eq-1)+n*(i_lag-1)+n),i+N);
          end
          BB_lag(t,:,:,i_lag) = tria(AA(t,:,i+N))*squeeze(B_lag(t,:,:,i_lag));
        end
        A_matrix(t,:,:) = tria(AA(t,:,i+N));
    end
    
    
    I(:,1)=-squeeze(A_matrix(:,i_policy,i_private));
    I(:,2)=-squeeze(A_matrix(:,i_policy,i_private))+ squeeze(BB_lag(:,i_policy,i_policy,1)).*I(:,1)+squeeze(BB_lag(:,i_policy,i_private,1)); %BB_lag= A*B_lag
    for j=3:max_horizon
        I(:,j)=-squeeze(A_matrix(:,i_policy,i_private))+ squeeze(BB_lag(:,i_policy,i_policy,1)).*I(:,j-1)+squeeze(BB_lag(:,i_policy,i_policy,2)).*I(:,j-2)...
            +squeeze(BB_lag(:,i_policy,i_private,1))+squeeze(BB_lag(:,i_policy,i_private,2));
    end
    II(:,:,i)=I(:,horizon);
end


end
