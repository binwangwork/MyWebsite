

rsmall.B=r.B(:,:,[int:int:end]);
rsmall.A=r.A(:,:,[int:int:end]);
rsmall.H=r.H(:,:,[int:int:end]);
rsmall.expH = exp(rsmall.H);     %the original Sigma matrix

rsmall.M=size(rsmall.B,3);
rsmall.N=round(N/int);
time=[2001.50:.25:2017.75];






                
%  % Convergence
% cd_B = convergence_cd(r.B,0.1*(M-N),0.5*(M-N));
% cd_A = convergence_cd(r.A,0.1*(M-N),0.5*(M-N));
% cd_H = convergence_cd(r.H,0.1*(M-N),0.5*(M-N));
% figure(1);
% title('Convergence Statistics: CD')
% subplot(3,1,1); 
% plot(1:length(cd_B(:)),cd_B(:));
% title('B')
% subplot(3,1,2); 
% plot(1:length(cd_A(:)),cd_A(:))
% title('A');
% subplot(3,1,3); 
% plot(1:length(cd_H(:)),cd_H(:))
% title('h');


%% 1. Parameters -------------------------------------------------------------------------------
%beta plot
figure;
for i= 1:r.k
    plot(time,prctile(squeeze(rsmall.B(:,i,rsmall.N:end))',50));hold on;
end
fig = gcf;
fig.PaperUnits = 'inches';
fig.PaperPosition = [0 0 8 4];
saveas(fig,'Bplot.png');


%alpha plot
figure;
plot(time,prctile(squeeze(rsmall.A(:,1,rsmall.N:end))',50),'-ob');hold on;
plot(time,prctile(squeeze(rsmall.A(:,2,rsmall.N:end))',50),'-*b');
plot(time,prctile(squeeze(rsmall.A(:,3,rsmall.N:end))',50),'-+b');
plot(time,prctile(squeeze(rsmall.A(:,4,rsmall.N:end))',50),'-sb');
plot(time,prctile(squeeze(rsmall.A(:,5,rsmall.N:end))',50),'-db');
plot(time,prctile(squeeze(rsmall.A(:,6,rsmall.N:end))',50),'-.b');
legend('\pi,g','i,g','i,\pi','m,g','m,\pi','m,i');
legend('Location','northwest');
fig = gcf;
fig.PaperUnits = 'inches';
fig.PaperPosition = [0 0 8 4];
saveas(fig,'Aplot.png');



%h plot
figure;
plot(time,prctile(squeeze(rsmall.H(:,1,rsmall.N:end))',50),'-b');hold on;
plot(time,prctile(squeeze(rsmall.H(:,2,rsmall.N:end))',50),'--b');
plot(time,prctile(squeeze(rsmall.H(:,3,rsmall.N:end))',50),':b');
plot(time,prctile(squeeze(rsmall.H(:,4,rsmall.N:end))',50),'-.b');
legend('g','\pi','i','m');
axis([2000 2018 -2 0.2]);
legend('Location','southwest');
fig = gcf;
fig.PaperUnits = 'inches';
fig.PaperPosition = [0 0 8 4];
saveas(fig,'Hplot.png');


%% 2. Impulse Response Functions --------------------------------------------------------------------------
%the impulse response in 2001:Q3 and 2017:Q4
a_all = [2001.50:0.25:2017.75];
response = impulse_response(rsmall.A,rsmall.B,rsmall.expH,r.n,lags,nstep,rsmall.M,rsmall.N,a_all);
figure;
i_graph = 1;
for j = 3:4
    for i = 1:2
        subplot(2,2,i_graph);
        for t =1:length(a_all)
              plot(prctile(squeeze(response(t,i,j,:,:))',50));hold on;
        end
        grid; set(gca,'xtick',[0 5 10 15 20]); hold on;axis([0 20 -.8 0.5]);
        title(strcat({'I.R. of '}, var_name_short(i), {' to '}, var_name_short(j), ' shock'));
        i_graph = i_graph + 1;
    end
end
fig = gcf;
fig.PaperUnits = 'inches';
fig.PaperPosition = [0 0 8 6];
saveas(fig,strcat('irf_all.png'));   


%irf before 2007
a_before_fc = [2001.50:0.25:2007.50];
response_before_fc = impulse_response(rsmall.A,rsmall.B,rsmall.expH,r.n,lags,nstep,rsmall.M,rsmall.N,a_before_fc);
figure;
i_graph = 1;
for j = 3:4
    for i = 1:2
        subplot(2,2,i_graph);
        for t =1:length(a_before_fc)
              plot(prctile(squeeze(response_before_fc(t,i,j,:,:))',50));hold on;
        end
        grid; set(gca,'xtick',[0 5 10 15 20]); hold on;axis([0 20 -.8 .5]);
        title(strcat({'I.R. of '}, var_name_short(i), {' to '}, var_name_short(j), ' shock'));
        i_graph = i_graph + 1;
    end
end
fig = gcf;
fig.PaperUnits = 'inches';
fig.PaperPosition = [0 0 8 6];
saveas(fig,strcat('irf_before_fc.png'));  


%irf according to 4 episodes
a_fc_before_sti = [2008:0.25:2008.75];
a_fc_in_sti = [2009:0.25:2010.75];
a_fc_after_sti = [2012:0.25:2013];
response_fc_before_sti = impulse_response(rsmall.A,rsmall.B,rsmall.expH,r.n,lags,nstep,rsmall.M,rsmall.N,a_fc_before_sti);
response_fc_in_sti = impulse_response(rsmall.A,rsmall.B,rsmall.expH,r.n,lags,nstep,rsmall.M,rsmall.N,a_fc_in_sti);
response_fc_after_sti = impulse_response(rsmall.A,rsmall.B,rsmall.expH,r.n,lags,nstep,rsmall.M,rsmall.N,a_fc_after_sti);
figure;
i_graph = 1;
for j = 3:4
    for i = 1:2
        subplot(2,2,i_graph);
        for t =1:length(a_before_fc)
              if t==1
               h1 = plot(prctile(squeeze(response_before_fc(t,i,j,:,:))',50),'black');hold on;
              end
              plot(prctile(squeeze(response_before_fc(t,i,j,:,:))',50),'black')
        end
        
        for t =1:length(a_fc_before_sti)
              if t==1
               h2 = plot(prctile(squeeze(response_fc_before_sti(t,i,j,:,:))',50),'blue');hold on;
              end
              plot(prctile(squeeze(response_fc_before_sti(t,i,j,:,:))',50),'blue')
        end
        
        for t =1:length(a_fc_in_sti)
              if t==1
               h3 = plot(prctile(squeeze(response_fc_in_sti(t,i,j,:,:))',50),'yellow');hold on;
              end
              plot(prctile(squeeze(response_fc_in_sti(t,i,j,:,:))',50),'yellow')
        end
        
        for t =1:length(a_fc_after_sti)
              if t==1
               h4 = plot(prctile(squeeze(response_fc_after_sti(t,i,j,:,:))',50),'red');hold on;
              end
              plot(prctile(squeeze(response_fc_after_sti(t,i,j,:,:))',50),'red')
        end
        grid; set(gca,'xtick',[0 5 10 15 20]); hold on;axis([0 20 -0.8 0.7]);
        title(strcat({'I.R. of '}, var_name_short(i), {' to '}, var_name_short(j), ' shock'));
        lgd = legend([h1 h2 h3 h4],{'2001-2007','2008','2009-2010','2011-2013'});
        lgd.FontSize = 7;
        i_graph = i_graph + 1;
    end
end
fig = gcf;
fig.PaperUnits = 'inches';
fig.PaperPosition = [0 0 8 6];
saveas(fig,strcat('irf_divided.png'));
        
%% 3. variance decomposition-------------------------------------------------------------------------------------
variance_decomposition;

              
%% 4. counterfactual analysis-------------------------------------------------------------------------------------
%what if there is no 4 trillion stimulus
%simulate the time series of 2008.75-2017.75 using the parameters of 2007.50
res=counter(y(T0+lags+1:end,:),rsmall.B,rsmall.A,rsmall.expH,r.n,lags,rsmall.M,rsmall.N,2008.75,2017.75,2007.50);
time_counter = (res.start:0.25:res.end);
T_counter = (time_counter-2001.25)*4;
figure;
subplot(2,1,1);
plot(time_counter,r.y(T_counter,1));hold on;
plot(time_counter,prctile(squeeze(res.YY(:,1,:))',50),'--b');
title('GDP Growth Rate');
plot(time_counter,prctile(squeeze(res.YY(:,1,:))',5),'--r');
plot(time_counter,prctile(squeeze(res.YY(:,1,:))',95),'--r');
lgd = legend('actual','counterfactural median','5 percentile','95 percentile');
lgd.FontSize = 6;
lgd.Location = 'southwest';
subplot(2,1,2);
plot(time_counter,r.y(T_counter,1)'-prctile(squeeze(res.YY(:,1,:))',50),'-o');hold on;
plot(time_counter,r.y(T_counter,1)'-prctile(squeeze(res.YY(:,1,:))',5),'--r');
plot(time_counter,r.y(T_counter,1)'-prctile(squeeze(res.YY(:,1,:))',95),'--r');
title('Difference between Actual and Counterfactual Median');
fig = gcf;
fig.PaperUnits = 'inches';
fig.PaperPosition = [0 0 8 6];
saveas(fig,strcat('cf_g.png'));

figure;
subplot(2,1,1);
plot(time_counter,r.y(T_counter,2));hold on;
plot(time_counter,prctile(squeeze(res.YY(:,2,:))',50),'--b')
title('Inflation Rate');
plot(time_counter,prctile(squeeze(res.YY(:,2,:))',5),'--r');
plot(time_counter,prctile(squeeze(res.YY(:,2,:))',90),'--r');
lgd = legend('actual','counterfactural median','5 percentile','95 percentile');
lgd.FontSize = 7;
subplot(2,1,2);
plot(time_counter,r.y(T_counter,2)'-prctile(squeeze(res.YY(:,2,:))',50),'-o'); hold on;
plot(time_counter,r.y(T_counter,2)'-prctile(squeeze(res.YY(:,2,:))',5),'--r');
plot(time_counter,r.y(T_counter,2)'-prctile(squeeze(res.YY(:,2,:))',95),'--r');
title('Difference between Actual and Counterfactual Median');
fig = gcf;
fig.PaperUnits = 'inches';
fig.PaperPosition = [0 0 8 6];
saveas(fig,strcat('cf_pi.png'));

% %permanant response of the policy to private sector variables
% 
% %response of money growth to 1% permanent increase of gdp growth
% horizon = [1 5  10  60];
% ps41 = permanent_response(rsmall.A,rsmall.B,r.n,lags,rsmall.M,rsmall.N,4,1,horizon);
% figure;
% for j=1:length(horizon)
%     subplot(2,2,j);hold on;
%     title(['horizon   ' num2str(horizon(j))]);
%     plot(time,prctile(squeeze(ps41(:,j,:))',50),'-b');
%     plot(time,prctile(squeeze(ps41(:,j,:))',84),'--r');
%     plot(time,prctile(squeeze(ps41(:,j,:))',16),'--r');
% end
% figure;
% plot(time,prctile(squeeze(ps41(:,1,:))',50),'-o');hold on;
% plot(time,prctile(squeeze(ps41(:,2,:))',50),'-+');
% plot(time,prctile(squeeze(ps41(:,3,:))',50),'-*');
% plot(time,prctile(squeeze(ps41(:,4,:))',50),'-s');
% legend('response after 0 quarters', 'response after 5 quarters' ,'response after 10 quarters' ,'response after 60 quarters');
% 
% %response of interest to 1% permanent increase of gdp growth
% ps31 = permanent_response(rsmall.A,rsmall.B,r.n,lags,rsmall.M,rsmall.N,3,1,horizon);
% figure;
% for j=1:length(horizon)
%     subplot(2,2,j);hold on;
%     title(['horizon   ' num2str(horizon(j))]);
%     plot(time,prctile(squeeze(ps31(:,j,:))',50),'-b');
%     plot(time,prctile(squeeze(ps31(:,j,:))',84),'--r');
%     plot(time,prctile(squeeze(ps31(:,j,:))',16),'--r');
% end
% 
% figure;
% plot(time,prctile(squeeze(ps31(:,1,:))',50),'-o');hold on;
% plot(time,prctile(squeeze(ps31(:,2,:))',50),'-+');
% plot(time,prctile(squeeze(ps31(:,3,:))',50),'-*');
% plot(time,prctile(squeeze(ps31(:,4,:))',50),'-s');
% legend('response after 0 quarters', 'response after 5 quarters' ,'response after 10 quarters' ,'response after 60 quarters');
% 
% %response of money growth to 1% permanent increase of inflation
% ps42 = permanent_response(rsmall.A,rsmall.B,r.n,lags,rsmall.M,rsmall.N,4,2,horizon);
% figure;
% for j=1:length(horizon)
%     subplot(2,2,j);hold on;
%     title(['horizon   ' num2str(horizon(j))]);
%     plot(time,prctile(squeeze(ps42(:,j,:))',50),'-b');
%     plot(time,prctile(squeeze(ps42(:,j,:))',84),'--r');
%     plot(time,prctile(squeeze(ps42(:,j,:))',16),'--r');
% end
% figure;
% plot(time,prctile(squeeze(ps42(:,1,:))',50),'-o');hold on;
% plot(time,prctile(squeeze(ps42(:,2,:))',50),'-+');
% plot(time,prctile(squeeze(ps42(:,3,:))',50),'-*');
% plot(time,prctile(squeeze(ps42(:,4,:))',50),'-s');
% legend('response after 0 quarters', 'response after 5 quarters' ,'response after 10 quarters' ,'response after 60 quarters');
% 
% %response of interest to 1% permanent increase of inflation
% ps32 = permanent_response(rsmall.A,rsmall.B,r.n,lags,rsmall.M,rsmall.N,3,2,horizon);
% figure;
% for j=1:length(horizon)
%     subplot(2,2,j);hold on;
%     title(['horizon   ' num2str(horizon(j))]);
%     plot(time,prctile(squeeze(ps32(:,j,:))',50),'-b');
%     plot(time,prctile(squeeze(ps32(:,j,:))',84),'--r');
%     plot(time,prctile(squeeze(ps32(:,j,:))',16),'--r');
% end
% 
% figure;
% plot(time,prctile(squeeze(ps32(:,1,:))',50),'-o');hold on;
% plot(time,prctile(squeeze(ps32(:,2,:))',50),'-+');
% plot(time,prctile(squeeze(ps32(:,3,:))',50),'-*');
% plot(time,prctile(squeeze(ps32(:,4,:))',50),'-s');
% legend('response after 0 quarters', 'response after 5 quarters' ,'response after 10 quarters' ,'response after 60 quarters');
% 
