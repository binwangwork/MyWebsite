close all;
clear all;
clc;

% load data
% y=data;
data = csvread('china_macrodata.csv',1,0);
%data = csvread('china_macrodata_logpolicy.csv',1,0);
%data = csvread('china_macrodata_target.csv',1,0);

ydata = data(:,2:5);
yearlab = data(:,1);
y=ydata;



lags=2;               %NO OF LAGS
T0=20;                %NO OF OBSERVSATIONS FOR CALIBRATING PRIORS
T0B=40;               %DEGREEE OF FREEDOM IN THE INVERSE WISHORT DISTRIBUTION OF SIGMA_BETA
T0A=[2 3 4];          %DEGREEE OF FREEDOM IN THE INVERSE WISHORT DISTRIBUTION OF SIGMA_ALPHA
T0H=5;                %DEGREEE OF FREEDOM IN THE INVERSE WISHORT DISTRIBUTION OF SIGMA_H

kB=.01;
kA=.1;
kH=.01;
nstep=20;
M=10000;
N=2000;


r=tvsvar(y,lags,T0,T0B,T0A,T0H,kB,kA,kH,M);

int=10; % thinning parameter (choose 1 if want to use all draws for constructing 
        % the final graphs; choose J if want to use one every J draws for 
        % constructing the final graphs) 

natural_interest_rate;

%robustness
robustness;
disp('real rate before 2011');
disp(mean(bm(1:38)));
disp('recent natural rate');
disp([bm(end)]);
disp('diff between natural rate and real rate');
disp([bm(end)-r.y(end,3)]);


