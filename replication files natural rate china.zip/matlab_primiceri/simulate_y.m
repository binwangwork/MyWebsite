%simulate y given B0 and B_lag
function simulate = simulate_y(y0,B0,B_lag,forecast_step)



[neq,nvar,nlag]=size(B_lag);
simulate = zeros(neq,forecast_step);

simulate(:,1) = B0 + B_lag(:,:,1)*y0;
simulate(:,2) = B0 + B_lag(:,:,1)*simulate(:,1) + B_lag(:,:,2)*y0; 

for it=3:forecast_step
   simulate(:,it) = B0;
   for ilag=1:nlag
      simulate(:,it)=simulate(:,it)+B_lag(:,:,ilag)*simulate(:,it-ilag);
   end
end